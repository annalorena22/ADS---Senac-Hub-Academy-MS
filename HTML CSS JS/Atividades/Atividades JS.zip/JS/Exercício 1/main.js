let f = window.prompt("Digite a temperatura  ser convertida:")

let c = (5/9) * (f - 32)

window.alert("O valor da conversão é: " + c.toFixed(0) + "°C")
